drop table vendor;
drop table customer;
drop table transaction;
